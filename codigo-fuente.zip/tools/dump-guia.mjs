import {GUIA} from '../src/guia-segunda-mano.mjs';
import {SITE} from '../src/data.mjs';
import fs from 'node:fs';
fs.writeFileSync(new URL('./guia.json',import.meta.url),JSON.stringify({GUIA,SITE},null,1));
