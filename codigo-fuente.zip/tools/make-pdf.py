import json, re, html, base64, pathlib
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parent.parent
d=json.load(open(root/'tools/guia.json')); G=d['GUIA']; S=d['SITE']
logo='data:image/png;base64,'+base64.b64encode((root/'src/brand/logo.png').read_bytes()).decode()
e=html.escape
def first(s):
    m=re.match(r'(.+?[.!?])(\s|$)',s); t=m.group(1) if m else s
    return t if len(t)<=170 else t[:167].rsplit(' ',1)[0]+'…'
secs=''
for i,s in enumerate(G['sections'],1):
    items=''.join(f'<li><span class="bx"></span><div><b>{e(t)}</b><span>{e(first(x))}</span></div></li>' for t,x in s['items'])
    tip=f'<p class="tip"><b>Consejo.</b> {e(s["tip"])}</p>' if s.get('tip') else ''
    secs+=f'<section class="{"alarm" if s.get("alarm") else ""}"><h2><i>{i}</i>{e(s["h"])}</h2><ul>{items}</ul>{tip}</section>'
css='''
@page{size:A4;margin:16mm 14mm 18mm}
*{box-sizing:border-box}body{font:9.2pt/1.35 "Inter","Helvetica Neue",Arial,sans-serif;color:#17171a;margin:0}
header{display:flex;align-items:center;justify-content:space-between;gap:12mm;border-bottom:2px solid #991B1B;padding-bottom:4mm;margin-bottom:5mm}
header img{height:13mm}h1{font-size:16pt;line-height:1.15;margin:0;text-align:right}h1 small{display:block;font-size:8.5pt;font-weight:600;color:#666;margin-top:1mm}
.data{display:grid;grid-template-columns:repeat(3,1fr);gap:2.5mm 5mm;margin-bottom:5mm}
.data div{border-bottom:1px solid #999;padding-bottom:1mm;font-size:7.8pt;color:#555;height:9mm}
.how{background:#f3f4f6;border-radius:2mm;padding:3mm 4mm;margin-bottom:5mm;font-size:8.6pt}
.how b{color:#991B1B}
section{margin-bottom:5mm;break-inside:auto}
h2{font-size:11.5pt;margin:0 0 2mm;display:flex;align-items:center;gap:2.5mm;break-after:avoid}
h2 i{font-style:normal;background:#991B1B;color:#fff;width:6mm;height:6mm;border-radius:50%;display:grid;place-items:center;font-size:9pt;font-weight:800;flex:none}
ul{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:1fr 1fr;gap:1.6mm 6mm}
li{display:flex;gap:2.2mm;break-inside:avoid;padding:1.4mm 0;border-bottom:.4pt solid #ddd}
.bx{flex:none;width:4mm;height:4mm;border:1.2pt solid #555;border-radius:1mm;margin-top:.4mm}
li b{display:block;font-size:9pt}li span:not(.bx){display:block;color:#555;font-size:7.8pt}
.tip{margin:2mm 0 0;font-size:8.2pt;border-left:1.2mm solid #991B1B;background:#f3f4f6;padding:1.5mm 3mm}
.alarm h2 i{background:#17171a}.alarm li{background:#fdf6f6}
.notes{break-inside:avoid}.notes .ln{height:7.5mm;border-bottom:.6pt solid #aaa}
.res{display:grid;grid-template-columns:repeat(3,1fr);gap:4mm;margin:3mm 0 5mm}
.res div{min-height:42mm;border:1pt solid #bbb;border-radius:2mm;padding:2.5mm;font-size:8.6pt}.res b{display:block;margin-bottom:1mm}
.cta{border:1.5pt solid #991B1B;border-radius:2.5mm;padding:4mm;break-inside:avoid;font-size:9pt}
.cta b{font-size:10.5pt;color:#991B1B}
'''
body=f'''<header><img src="{logo}"><h1>Checklist para revisar un coche de segunda mano<small>Llévalo impreso o en el móvil · {e(S["name"])}</small></h1></header>
<div class="data"><div>Vehículo (marca, modelo, versión)</div><div>Matrícula</div><div>Nº de bastidor (VIN)</div><div>Kilómetros</div><div>Precio pedido</div><div>Vendedor / teléfono</div></div>
<div class="how"><b>Cómo usarlo.</b> Marca cada casilla cuando la hayas comprobado y anota al margen lo que no cuadre. Haz la revisión de día, con el coche seco y en frío. Si aparecen varias señales de alarma, no sigas adelante. La explicación completa de cada punto está en la guía de nuestra web.</div>
{secs}
<section class="notes"><h2><i>+</i>Notas y valoración</h2><div class="ln"></div><div class="ln"></div><div class="ln"></div><div class="ln"></div><div class="res"><div><b>Lo que me gusta</b></div><div><b>Lo que no cuadra</b></div><div><b>Qué negociar / reparar antes</b></div></div></section>
<div class="cta"><b>¿Quieres que lo revisemos contigo?</b><br>En {e(S["name"])} cada coche pasa una revisión previa y lleva 12 meses de garantía. {e(S["street"])}, {e(S["city"])} · Tel. {e(S["phone"])} · {e(S["email"])} · {e(S["url"].replace("https://",""))}</div>'''
doc=f'<!doctype html><html lang="es"><meta charset="utf-8"><style>{css}</style><body>{body}</body></html>'
out=root/'src/guia-checklist.pdf'
foot=f'<div style="font:7pt Arial;color:#777;width:100%;padding:0 14mm;display:flex;justify-content:space-between"><span>{e(S["name"])} · {e(S["url"].replace("https://",""))}</span><span>Página <span class="pageNumber"></span> de <span class="totalPages"></span></span></div>'
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page();pg.set_content(doc);pg.wait_for_timeout(300)
    pg.pdf(path=str(out),format='A4',print_background=True,display_header_footer=True,header_template='<span></span>',footer_template=foot,margin={'top':'16mm','bottom':'18mm','left':'14mm','right':'14mm'})
    b.close()
print(out.stat().st_size)
