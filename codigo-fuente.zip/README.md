# MZ Garage · web nueva

Sitio estático (22 páginas) generado con Node, sin dependencias.

    node build.mjs            # → dist/ (rutas limpias, para producción)
    node build.mjs --preview  # → dist-preview/ (enlaces con index.html, para vistas previas)

## Dónde editar
- `src/data.mjs`: datos del negocio (teléfono, horario, dirección), stock (`VEHICLES`), FAQs y guías.
- `src/style.css` y `src/app.js`: diseño y comportamiento (se inlinean en cada página).
- `build.mjs`: plantillas, datos estructurados, sitemap, robots y llms.txt.

## Antes de publicar (pendiente del cliente)
1. Confirmar teléfono, WhatsApp, horario y dirección (la web actual tenía datos contradictorios).
2. Stock: hay 9 de los 28 vehículos actuales. Añadir el resto y fotos reales (añadir `photo` y mostrar `<img>` en `carCard`/`ficha`).
3. Equipo real en «Quiénes somos» (nombres y fotos) y datos legales en `legal/`.
4. Confirmar respuestas de FAQ: parte de pago, control de calidad, condiciones de entrega a domicilio.
5. Enlazar la ficha de Google en `opiniones/` y añadir `sameAs` (Instagram, Google) al JSON-LD.
6. Los formularios abren WhatsApp con el mensaje preparado. Si se quiere guardar leads, conectar un endpoint.
7. Tras el lanzamiento: redirecciones 301 desde `/buy/<uuid>` y otras URLs antiguas, y alta en Search Console.
