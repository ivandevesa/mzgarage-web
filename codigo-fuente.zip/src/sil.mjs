// Siluetas de perfil vectorizadas (frontal a la derecha). Se pintan con currentColor.
import fs from 'node:fs';
const P = JSON.parse(fs.readFileSync(new URL('./sil-paths.json', import.meta.url), 'utf8'));
const MAP = { 'Berlina':'Sedán','Sedán':'Sedán','Coupé':'Deportivo','Deportivo':'Deportivo','Cabrio':'Cabrio','Familiar':'Familiar','Compacto':'Familiar','Monovolumen':'Monovolumen','Furgoneta':'Furgoneta','Furgón':'Furgoneta' };
export const silSVG=(b,{aria=true}={})=>{ const k=/SUV|4x4/.test(b)?'SUV':(MAP[b]||'Sedán'); const s=P[k];
 return `<svg class="sil" viewBox="0 0 ${s.w} ${s.h}" ${aria?`role="img" aria-label="Silueta de ${b}"`:'aria-hidden="true"'}><path fill-rule="evenodd" d="${s.d}"/></svg>`; };
