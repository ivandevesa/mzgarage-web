// Textos legales facilitados por el cliente (estructurados, sin cambiar su contenido).
export const LEGAL = [
 {id:'aviso', title:'1. Aviso legal', html:`
<h3>1.1 Identificación del titular</h3>
<p>En cumplimiento de la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Información y de Comercio Electrónico (LSSICE), se informa que el presente sitio web es propiedad de:</p>
<ul><li><b>Titular:</b> MZ Garage Barcelona SL</li><li><b>CIF/NIF:</b> B19726603</li><li><b>Domicilio social:</b> Serralada 47, 08206, Sabadell</li><li><b>Teléfono:</b> 667381202</li><li><b>Correo electrónico:</b> mzgaragebarcelona@gmail.com</li></ul>
<h3>1.2 Condiciones de uso</h3>
<p>El acceso y uso del sitio web atribuyen la condición de usuario e implican la aceptación de las siguientes condiciones:</p>
<ul><li>El usuario se compromete a utilizar el sitio de forma lícita y conforme a la normativa vigente.</li><li>La empresa puede modificar en cualquier momento los contenidos y condiciones del sitio sin previo aviso.</li><li>No se garantiza la disponibilidad permanente del sitio ni la ausencia de errores.</li></ul>
<h3>1.3 Propiedad intelectual e industrial</h3>
<p>Todos los contenidos del sitio web (textos, imágenes, logotipos, diseños, etc.) son propiedad de MZ Garage Barcelona SL o de terceros autorizados. Queda prohibida su reproducción, distribución o modificación sin autorización expresa.</p>
<h3>1.4 Responsabilidad</h3>
<p>No nos hacemos responsables del uso indebido del sitio web ni de los enlaces de terceros que puedan aparecer en él.</p>
<h3>1.5 Legislación y jurisdicción</h3>
<p>Este aviso legal se rige por la legislación española. Para cualquier controversia, las partes se someten a los tribunales de Sabadell.</p>`},
 {id:'privacidad', title:'2. Política de privacidad', html:`
<h3>2.1 Responsable del tratamiento de datos</h3>
<ul><li><b>Nombre de la empresa:</b> MZ Garage Barcelona SL</li><li><b>Dirección:</b> Serralada 47, 08206, Sabadell</li><li><b>Correo electrónico:</b> mzgaragebarcelona@gmail.com</li><li><b>Teléfono:</b> 667381202</li></ul>
<h3>2.2 Datos que recopilamos</h3>
<p>Podemos recopilar los siguientes datos personales:</p>
<ul><li>Nombre y apellidos</li><li>DNI/NIE o número de identificación fiscal</li><li>Correo electrónico y teléfono</li><li>Dirección postal</li><li>Datos de navegación mediante cookies (ver nuestra Política de cookies)</li></ul>
<h3>2.3 Finalidad del tratamiento</h3>
<p>Usamos sus datos para:</p>
<ul><li>Gestionar la compra y venta de vehículos</li><li>Gestionar garantías, seguros y financiación</li><li>Cumplir con obligaciones legales</li></ul>
<h3>2.4 Derechos del usuario</h3>
<p>Tiene derecho a acceder, rectificar, suprimir o limitar el tratamiento de sus datos enviando un correo a mzgaragebarcelona@gmail.com.</p>`},
 {id:'cookies', title:'3. Política de cookies', html:`
<h3>3.1 ¿Qué son las cookies?</h3>
<p>Las cookies son archivos que se almacenan en su dispositivo cuando visita nuestro sitio web. Nos permiten mejorar su experiencia y ofrecer publicidad relevante.</p>
<h3>3.2 Tipos de cookies que usamos</h3>
<ul><li><b>Estrictamente necesarias:</b> permiten el funcionamiento del sitio web.</li><li><b>De personalización:</b> recuerdan sus preferencias.</li><li><b>Analíticas:</b> nos ayudan a mejorar el sitio.</li><li><b>Publicitarias:</b> muestran anuncios adaptados a sus intereses.</li></ul>
<h3>3.3 Gestión de cookies</h3>
<p>Puede aceptar, rechazar o configurar las cookies desde el banner de cookies o desde la configuración de su navegador.</p>`},
 {id:'terminos', title:'4. Términos y condiciones', html:`
<h3>4.1 Servicios ofrecidos</h3>
<p>A través de este sitio web, ofrecemos:</p>
<ul><li>Compra y venta de vehículos</li><li>Servicios de financiación y garantías</li><li>Asesoramiento en trámites administrativos</li></ul>
<h3>4.2 Condiciones de uso</h3>
<ul><li>El usuario se compromete a utilizar el sitio de manera legal y responsable.</li><li>Nos reservamos el derecho a modificar contenido y condiciones sin previo aviso.</li><li>No garantizamos la exactitud o actualización permanente de la información.</li></ul>
<h3>4.3 Registro y datos del usuario</h3>
<p>Para acceder a ciertos servicios, el usuario puede necesitar registrarse y proporcionar datos personales. Estos datos se tratarán conforme a nuestra Política de privacidad.</p>
<h3>4.4 Precios y pagos</h3>
<p>Los precios de los vehículos y servicios mostrados en la web pueden estar sujetos a cambios y no constituyen una oferta vinculante.</p>
<h3>4.5 Derecho de desistimiento</h3>
<p>El usuario podrá ejercer su derecho de desistimiento dentro de los 14 días posteriores a la compra, conforme a la normativa vigente.</p>
<h3>4.6 Legislación aplicable y jurisdicción</h3>
<p>Estos términos se rigen por la legislación española. Cualquier disputa será resuelta en los tribunales de Sabadell.</p>`}
];
