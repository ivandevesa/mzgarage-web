// Al entrar en una página desde un enlace o botón, siempre empieza arriba (atrás/adelante conserva la posición)
(function(){try{var n=performance.getEntriesByType('navigation')[0];if(n&&n.type!=='navigate')return}catch(e){}
 if(location.hash)try{history.replaceState(null,'',location.pathname+location.search)}catch(e){}
 var top=function(){window.scrollTo(0,0)};top();addEventListener('load',top);setTimeout(top,60);setTimeout(top,300)})();
(function(){
var d=document,$=function(s,r){return (r||d).querySelector(s)},$$=function(s,r){return Array.prototype.slice.call((r||d).querySelectorAll(s))};
// tema
var tb=$('#theme');if(tb){try{var t=localStorage.getItem('mz-theme');if(t)d.documentElement.setAttribute('data-theme',t)}catch(e){}
tb.addEventListener('click',function(){var cur=d.documentElement.getAttribute('data-theme')||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light');var n=cur==='dark'?'light':'dark';d.documentElement.setAttribute('data-theme',n);try{localStorage.setItem('mz-theme',n)}catch(e){}})}
$$('.fav').forEach(function(f){f.addEventListener('click',function(e){e.preventDefault();var on=f.getAttribute('aria-pressed')!=='true';f.setAttribute('aria-pressed',on);f.textContent=on?'★':'☆'})});
$$('.thumb').forEach(function(t){t.addEventListener('click',function(){var m=$('#gmain');m.src=t.dataset.src;m.alt=t.dataset.alt;var n=$('#gcount');if(n)n.textContent=t.dataset.n+' / '+$$('.thumb').length;$$('.thumb').forEach(function(x){x.setAttribute('aria-pressed',x===t)})})});
// menú
var bg=$('#burger'),nv=$('#nav');if(bg){var bd=document.createElement('div');bd.className='menu-bd';bg.closest('header').appendChild(bd);var setM=function(o){nv.classList.toggle('open',o);bd.classList.toggle('on',o);bg.setAttribute('aria-expanded',o);bg.textContent=o?'\u2715':'\u2630';bg.setAttribute('aria-label',o?'Cerrar menú':'Abrir menú');document.documentElement.classList.toggle('noscroll',o)};bg.addEventListener('click',function(){setM(!nv.classList.contains('open'))});bd.addEventListener('click',function(){setM(false)});nv.addEventListener('click',function(e){if(e.target.closest('a'))setM(false)});document.addEventListener('keydown',function(e){if(e.key==='Escape'&&nv.classList.contains('open')){setM(false);bg.focus()}});matchMedia('(min-width:1121px)').addEventListener('change',function(){setM(false)})}
// pestañas de intención
$$('[role=tablist]').forEach(function(tl){var tabs=$$('[role=tab]',tl);tabs.forEach(function(tab){tab.addEventListener('click',function(){tabs.forEach(function(x){x.setAttribute('aria-selected',x===tab);var p=d.getElementById(x.getAttribute('aria-controls'));if(p)p.hidden=x!==tab})})})});
// formularios -> WhatsApp (no se envía nada hasta que la persona lo manda)
$$('form[data-wa]').forEach(function(f){f.addEventListener('submit',function(e){e.preventDefault();
 var lines=[f.getAttribute('data-wa')];$$('input,select,textarea',f).forEach(function(i){if(i.type!=='checkbox'&&i.value)lines.push(((i.labels&&i.labels[0]?i.labels[0].firstChild.textContent.trim():i.name)+': '+i.value))});
 var msg=lines.join('\n'),out=$('.wa-out',f.parentNode)||$('.wa-out');if(!out)return;$('p',out).textContent=msg;
 $('a',out).setAttribute('href','https://wa.me/'+f.getAttribute('data-num')+'?text='+encodeURIComponent(msg));out.hidden=false;out.scrollIntoView({block:'nearest'})})});
// listado
var list=$('#cars');if(list){var cards=$$('.car',list),ids=['q','brand','fuel','gear','body','year','km','max','sort'],fs={};ids.forEach(function(k){fs[k]=$('#f-'+k)});var cnt=$('#count'),em=$('#empty'),form=$('#filters');
 try{var q=new URLSearchParams(location.search);ids.forEach(function(k){if(q.get(k)&&fs[k])fs[k].value=q.get(k)})}catch(e){}
 var norm=function(t){return t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')};
 function run(){var words=norm(fs.q.value).split(/\s+/).filter(Boolean),n=0;cards.forEach(function(c){var d=c.dataset,t=norm(d.text),ok=words.every(function(w){return t.indexOf(w)>-1})&&(!fs.brand.value||d.brand===fs.brand.value)&&(!fs.fuel.value||d.fuel===fs.fuel.value)&&(!fs.gear.value||d.gear===fs.gear.value)&&(!fs.body.value||d.body===fs.body.value)&&(!fs.year.value||+d.year>=+fs.year.value)&&(!fs.km.value||+d.km<=+fs.km.value)&&(!fs.max.value||+d.price<=+fs.max.value);c.hidden=!ok;if(ok)n++});
 var k={'price-asc':function(a,b){return a.dataset.price-b.dataset.price},'price-desc':function(a,b){return b.dataset.price-a.dataset.price},'km':function(a,b){return a.dataset.km-b.dataset.km},'year':function(a,b){return b.dataset.year-a.dataset.year}}[fs.sort.value];
 (k?cards.slice().sort(k):cards.slice().sort(function(a,b){return a._i-b._i})).forEach(function(c){list.appendChild(c)});
 cnt.textContent=n+(n===1?' vehículo encontrado':' vehículos encontrados');em.hidden=n>0}
 cards.forEach(function(c,i){c._i=i});
 form.addEventListener('submit',function(e){e.preventDefault();run();list.scrollIntoView({behavior:'smooth',block:'start'})});
 form.addEventListener('reset',function(){setTimeout(run,0)});
 fs.sort.addEventListener('change',run);run()}
// tasación por pasos
var wz=$('#wiz');if(wz){var ps=$$('.wp',wz),sts=$$('.wsteps li',wz),cur=0,tipo='',er=$('#werr'),nx=$('#wnext'),pv=$('#wprev'),sd=$('#wsend'),files=[],
 BODY={'Turismo':['Berlina','Coupé','Cabrio','Familiar','Monovolumen','SUV'],'Vehículo industrial':['Furgón','Furgoneta','Furgoneta frigorífica','Camión ligero','Pick-up']};
 $$('.vtype button').forEach(function(b){b.addEventListener('click',function(){tipo=b.dataset.tipo;$$('.vtype button').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-checked',x===b)});
  var sb=$('#t-body');sb.innerHTML='<option value="">Seleccione una carrocería</option>'+BODY[tipo].map(function(o){return'<option>'+o+'</option>'}).join('');$('#wtype').textContent=tipo;
  var first=wz.hidden;wz.hidden=false;if(first||cur!==0)show(0);wz.scrollIntoView({behavior:'smooth',block:'start'})})});
 function show(n){cur=n;ps.forEach(function(p,i){p.classList.toggle('on',i===n)});sts.forEach(function(s,i){s.classList.toggle('on',i===n);s.classList.toggle('done',i<n)});pv.hidden=n===0;nx.hidden=n===4;sd.hidden=n!==4;er.hidden=true;if(n===4)sum()}
 function val(){var bad=null;$$('input[required],select[required]',ps[cur]).forEach(function(i){if(bad)return;if(i.type==='checkbox'?!i.checked:!i.value.trim())bad=i});if(bad){var l=bad.type==='checkbox'?'la política de privacidad (acepta para continuar)':(bad.labels&&bad.labels[0]?bad.labels[0].firstChild.textContent.trim():'');er.textContent=bad.type==='checkbox'?'Para continuar, acepta la política de privacidad.':'Completa este campo para continuar: '+l+'.';er.hidden=false;bad.focus();return false}return true}
 function data(){var g=function(i){var e=$('#t-'+i);return e?(e.value||'').trim():''},r=function(n){var e=$('input[name='+n+']:checked',wz);return e?e.value:''};return[['Tipo',tipo],['Marca',g('marca')],['Modelo',g('modelo')],['Año',g('anio')],['Carrocería',g('body')],['Color',g('color')],['Combustible',g('fuel')],['Cambio',r('gear')],['Versión',g('version')],['Kilometraje',g('km')],['Matrícula',g('plate')],['Fotos',files.length?files.length+' (las adjunto en WhatsApp)':''],['Cuándo planea venderlo',g('when')],['Comprar coche a cambio',r('swap')],['Nombre',g('nombre')],['Código postal',g('zip')],['Email',g('email')],['Teléfono',g('tel')]].filter(function(x){return x[1]})}
 function sum(){var d=$('#sum');d.innerHTML='';data().forEach(function(r){var a=document.createElement('dt'),b=document.createElement('dd');a.textContent=r[0];b.textContent=r[1];d.appendChild(a);d.appendChild(b)})}
 // fotos
 var dz=$('#drop'),fi=$('#t-fotos'),pvw=$('#pv');
 function addF(l){Array.prototype.forEach.call(l,function(f){if(/^image\//.test(f.type)&&files.length<12)files.push(f)});pvw.innerHTML='';files.forEach(function(f,i){var im=document.createElement('img');im.alt='Foto '+(i+1);im.src=URL.createObjectURL(f);pvw.appendChild(im)})}
 fi.addEventListener('change',function(){addF(fi.files)});['dragover','dragenter'].forEach(function(t){dz.addEventListener(t,function(e){e.preventDefault();dz.classList.add('over')})});['dragleave','drop'].forEach(function(t){dz.addEventListener(t,function(e){e.preventDefault();dz.classList.remove('over');if(t==='drop')addF(e.dataTransfer.files)})});
 nx.addEventListener('click',function(){if(val())show(cur+1)});pv.addEventListener('click',function(){show(cur-1)});
 wz.addEventListener('keydown',function(e){if(e.key==='Enter'&&e.target.tagName!=='TEXTAREA'&&e.target.type!=='checkbox'&&cur<4){e.preventDefault();nx.click()}});
 wz.addEventListener('submit',function(e){e.preventDefault();var m='Hola, quiero tasar mi vehículo.\n'+data().map(function(r){return r[0]+': '+r[1]}).join('\n'),o=$('.wa-out',wz);$('p',o).textContent=m;$('a',o).setAttribute('href','https://wa.me/'+wz.dataset.num+'?text='+encodeURIComponent(m));var n=$('#phnote');if(files.length){n.textContent='Recuerda adjuntar tus '+files.length+' fotos en el chat de WhatsApp.';n.hidden=false}o.hidden=false;o.scrollIntoView({block:'nearest'})});
 show(0)}
// textos legales en ventana
(function(){var ls=$$('a[data-legal]');if(!ls.length||!window.HTMLDialogElement)return;var dlg=null,cache=null,body,ttl;
 function mk(){dlg=document.createElement('dialog');dlg.className='lgdlg';dlg.setAttribute('aria-labelledby','lg-t');dlg.innerHTML='<div class="lg-in"><button type="button" class="lg-x" aria-label="Cerrar">\u00d7</button><div class="lg-body" tabindex="-1"></div></div>';document.body.appendChild(dlg);body=$('.lg-body',dlg);
  $('.lg-x',dlg).addEventListener('click',function(){dlg.close()});dlg.addEventListener('click',function(e){if(e.target===dlg)dlg.close()});dlg.addEventListener('close',function(){document.documentElement.classList.remove('noscroll')})}
 function load(){if(cache)return Promise.resolve(cache);var u=ls[0].href.split('#')[0];return fetch(u).then(function(r){if(!r.ok)throw 0;return r.text()}).then(function(t){cache=new DOMParser().parseFromString(t,'text/html');return cache})}
 ls.forEach(function(a){a.addEventListener('click',function(e){var id=a.getAttribute('data-legal'),here=document.getElementById(id);if(here&&here.classList.contains('lg'))return;e.preventDefault();
  load().then(function(d){var s=d.getElementById(id);if(!s)throw 0;if(!dlg)mk();body.innerHTML=s.innerHTML;var h=$('h2',body);if(h)h.id='lg-t';document.documentElement.classList.add('noscroll');dlg.showModal();body.scrollTop=0;body.focus()}).catch(function(){location.href=a.href})})})})();
// camino
var tr=$('#trail');if(tr){var svg=$('svg',tr),A=$('.asphalt',svg),D=$('.dash',svg),F=$('.done',svg),V=$('.vehicle',svg),stops=$$('.stop',tr),len=0,pts=[];tr.classList.add('js');
 function build(){var r=tr.getBoundingClientRect();svg.setAttribute('width',r.width);svg.setAttribute('height',r.height);svg.setAttribute('viewBox','0 0 '+r.width+' '+r.height);
  pts=stops.map(function(s){var n=$('.node',s).getBoundingClientRect();return{x:n.left+n.width/2-r.left,y:n.top+n.height/2-r.top}});
  var mx=pts[0].x,dd='M'+mx+' 0 L'+pts[0].x+' '+(pts[0].y-60)+' C'+pts[0].x+' '+(pts[0].y-20)+' '+pts[0].x+' '+(pts[0].y-20)+' '+pts[0].x+' '+pts[0].y;
  for(var i=1;i<pts.length;i++){var a=pts[i-1],b=pts[i],m=(a.y+b.y)/2;dd+=' C'+a.x+' '+m+' '+b.x+' '+m+' '+b.x+' '+b.y}
  var l=pts[pts.length-1];dd+=' L'+l.x+' '+r.height;[A,D,F].forEach(function(p){p.setAttribute('d',dd)});len=A.getTotalLength();F.style.strokeDasharray=len;update()}
 function update(){if(!len)return;var r=tr.getBoundingClientRect(),vh=innerHeight,y=vh*.55-r.top,p=Math.max(0,Math.min(1,y/r.height)),L=p*len;
  F.style.strokeDashoffset=len-L;var a=A.getPointAtLength(L),b=A.getPointAtLength(Math.min(len,L+2)),c=A.getPointAtLength(Math.max(0,L-2));
  V.setAttribute('transform','translate('+a.x+' '+a.y+') rotate('+(Math.atan2(b.y-c.y,b.x-c.x)*180/Math.PI)+')');
  stops.forEach(function(s,i){s.classList.toggle('on',a.y>=pts[i].y-4)})}
 build();addEventListener('scroll',update,{passive:true});addEventListener('resize',build);addEventListener('load',build);if(document.fonts&&document.fonts.ready)document.fonts.ready.then(build)}
// simulador
var cc=$('#calc');if(cc){try{var qp=new URLSearchParams(location.search).get('precio');if(qp&&+qp>0)$('#c-precio').value=+qp}catch(e){}var g=function(i){return +$('#'+i).value||0};function pay(){var P=g('c-precio')-g('c-entrada'),n=g('c-plazo'),r=g('c-tin')/100/12,m=P<=0?0:(r?P*r/(1-Math.pow(1+r,-n)):P/n);$('#c-out').textContent=new Intl.NumberFormat('es-ES',{maximumFractionDigits:0}).format(m)+' €/mes';
 $('#c-tot').textContent='Total a devolver orientativo: '+new Intl.NumberFormat('es-ES',{maximumFractionDigits:0}).format(m*n+g('c-entrada'))+' €'}
 $$('input,select',cc).forEach(function(i){i.addEventListener('input',pay)});pay()}
})();

// guía: checklist con progreso
(function(){var p=document.getElementById('gprog');if(!p)return;var boxes=[].slice.call(document.querySelectorAll('.ck input')),key='mzg-ck-'+location.pathname,bar=p.querySelector('i'),num=p.querySelector('b');
 var saved={};try{saved=JSON.parse(localStorage.getItem(key)||'{}')}catch(e){}
 function paint(){var n=boxes.filter(function(b){return b.checked}).length;num.textContent=n;bar.style.width=(n/boxes.length*100)+'%'}
 boxes.forEach(function(b){if(saved[b.dataset.k])b.checked=true;b.addEventListener('change',function(){saved[b.dataset.k]=b.checked||undefined;try{localStorage.setItem(key,JSON.stringify(saved))}catch(e){}paint()})});
 document.getElementById('greset').addEventListener('click',function(){boxes.forEach(function(b){b.checked=false});saved={};try{localStorage.removeItem(key)}catch(e){}paint()});paint()})();

// cabecera compacta al bajar + medidas reales para el banner de portada
(function(){var h=document.querySelector('.top');if(!h)return;var root=document.documentElement,on=false,tick=false;
function measure(){if(on)return;root.style.setProperty('--hdr',h.offsetHeight+'px');var st=document.querySelector('.strip');if(st)root.style.setProperty('--strp',st.offsetHeight+'px')}
function upd(){tick=false;var y=window.pageYOffset||0;if(!on&&y>70){on=true;h.classList.add('compact')}else if(on&&y<12){on=false;h.classList.remove('compact')}}
addEventListener('scroll',function(){if(!tick){tick=true;requestAnimationFrame(upd)}},{passive:true});
addEventListener('resize',measure);addEventListener('load',measure);measure();upd()})();

// rellena el hueco de la última fila del listado con una tarjeta de "búsqueda a medida"
(function(){var list=document.getElementById('cars'),f=document.getElementById('carfill');if(!list||!f)return;var busy=false;
function fill(){if(busy)return;busy=true;list.appendChild(f);f.classList.remove('on');f.style.gridColumn='';
 var cols=getComputedStyle(list).gridTemplateColumns.split(' ').length,n=0,cs=list.children;
 for(var i=0;i<cs.length;i++){var e=cs[i];if(e!==f&&e.classList.contains('car')&&!e.hidden&&e.offsetParent!==null)n++}
 var rem=n%cols;if(n>0&&cols>1&&rem>0){f.classList.add('on');f.style.gridColumn='span '+(cols-rem)}
 busy=false}
var t;function q(){clearTimeout(t);t=setTimeout(fill,30)}
addEventListener('resize',q);addEventListener('load',q);
['input','change','submit','click'].forEach(function(ev){var fm=document.getElementById('filters');if(fm)fm.addEventListener(ev,q)});
if(window.MutationObserver)new MutationObserver(function(m){if(!busy)q()}).observe(list,{attributes:true,childList:true,subtree:true,attributeFilter:['hidden','style','class']});
q()})();
