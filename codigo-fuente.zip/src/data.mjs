export const SITE = {
  name: 'MZ Garage',
  legal: 'MZ Garage – Compra y venta de vehículos premium',
  url: 'https://www.mzgaragebarcelona.es',
  phone: '604 257 365', phoneTel: '+34604257365', wa: '34604257365',
  email: 'mzgaragebarcelona@gmail.com',
  street: 'C. Penedés 37', city: 'Sant Quirze del Vallès', region: 'Barcelona',
  hours: 'Lunes a viernes de 10:00 a 14:00 y de 16:00 a 20:00. Sábados con cita previa.',
  updated: '2026-10-17',
};
import fs from 'node:fs';
const BRAND={'MASERATI':'Maserati','LAND ROVER':'Land Rover','BMW':'BMW','AUDI':'Audi','PORSCHE':'Porsche','VOLKSWAGEN':'Volkswagen','FORD':'Ford','CUPRA':'Cupra','MERCEDES-BENZ':'Mercedes-Benz'};
const BODY={'SUV / 4x4':'SUV','Cabrio | Descapotable':'Cabrio','Roadster':'Cabrio','Coupé':'Coupé','Berlina':'Berlina','Compacto':'Compacto','Familiar':'Familiar'};
const slugify = t => t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
const raw = JSON.parse(fs.readFileSync(new URL('./vehicles.json', import.meta.url),'utf8'));
const used = new Set();
// el orden de la web actual es el inverso al del listado del sitemap
export const VEHICLES = raw.map((r,i)=>{
  let brand=r.brand, model=r.model; if(brand==='LAND'){brand='LAND ROVER';model=model.replace(/^ROVER /,'')}
  const b=BRAND[brand]||brand;
  let id=slugify(`${b} ${model} ${r.version.split(' ').slice(0,4).join(' ')} ${r.year}`); if(used.has(id)) id+='-'+r.uuid.slice(0,4); used.add(id);
  let body=BODY[r.basic['CARROCERÍA']]||'Berlina'; if(model==='Panamera') body='Berlina';
  const imgs=[0,1,2,3].map(k=>`src/cars/${String(i).padStart(2,'0')}-${k}.webp`).filter(p=>fs.existsSync(new URL('../'+p, import.meta.url)));
  return { id, idx:i, uuid:r.uuid, brand:b, model, version:r.version, year:r.year, km:r.km, fuel:r.fuel==='Diesel'?'Diésel':r.fuel, gear:r.gear, price:r.price, body, cv:r.cv, loc:r.loc, desc:r.desc, basic:r.basic, tech:r.tech, cons:r.cons, co2:r.co2, dims:r.dims, peso:r.peso, imgs };
}).reverse();
export const FAQ = [
 ['¿Cómo reservo un coche?','Elige el coche, pulsa «Reservar» y escríbenos por WhatsApp o rellena el formulario de la ficha. Te confirmamos que sigue disponible y te explicamos los pasos para dejarlo apartado.'],
 ['¿Qué cubre la garantía de vuestros coches?','Todos los vehículos incluyen 12 meses de garantía. Antes de comprar te explicamos qué cubre, qué no y cómo se tramita una incidencia.'],
 ['¿Cuál es vuestro horario?','Abrimos de lunes a viernes de 10:00 a 14:00 y de 16:00 a 20:00. Los sábados atendemos con cita previa.'],
 ['¿Dónde está MZ Garage?','En C. Penedés 37, Sant Quirze del Vallès (Barcelona). Atendemos a clientes de Barcelona, Sabadell, Terrassa y todo el Vallès.'],
 ['¿Aceptáis mi coche como parte de pago?','Sí. Valoramos tu coche y puedes usarlo como parte del pago del que compras. Te damos la cifra antes de que decidas nada.'],
 ['¿Cómo funciona la tasación de mi coche?','Rellenas el formulario con marca, modelo, año y kilómetros y recibes una oferta personalizada. Si te encaja, concertamos cita para ver el coche y cerrar la compra.'],
 ['¿Podéis financiar mi compra?','Sí. Te presentamos opciones de financiación flexibles según tu entrada y el plazo que prefieras. La aprobación final depende de la entidad financiera.'],
 ['¿Hacéis entrega a domicilio?','Sí, entregamos en toda la península. Dinos tu zona y coordinamos día y hora.'],
 ['¿Qué hago si no tenéis el coche que busco?','Te lo buscamos. Cuéntanos modelo, presupuesto y kilometraje máximo y te avisamos cuando encontremos opciones.'],
 ['¿Podéis vender mi coche por mí?','Sí, con el servicio de gestión de venta nos encargamos de todo el proceso para conseguir el mejor valor por tu vehículo.'],
 ['¿Qué gastos hay además del precio?','Cada ficha detalla sus condiciones de venta. En muchos coches el cambio de titularidad y la documentación cuestan 250 €. Te lo confirmamos antes de reservar.'],
 ['¿Qué control de calidad pasan los coches?','Cada vehículo se revisa antes de ponerlo a la venta. Si quieres ver un coche concreto con calma, pide cita y lo revisamos juntos.'],
];
export const GUIDES = [
 { slug:'que-revisar-antes-de-comprar-un-coche-premium', title:'Qué revisar antes de comprar un coche premium de ocasión',
   answer:'Antes de comprar pide el historial de mantenimiento, comprueba que los kilómetros encajan con él, revisa el informe oficial de la DGT, haz una prueba en carretera y confirma por escrito la garantía.',
   body:[['Historial de mantenimiento','En coches de gama alta el mantenimiento al día pesa más que el año. Pide facturas o el libro de revisiones y comprueba que las fechas y los kilómetros siguen una línea lógica.'],
         ['Informe de la DGT','El informe del vehículo indica titulares, cargas, ITV y baja temporal si la hubiera. Pídelo antes de pagar ninguna señal.'],
         ['Prueba en carretera','Prueba el coche en frío, con ciudad y vía rápida. Fíjate en la caja de cambios, los frenos, ruidos de suspensión y testigos del cuadro.'],
         ['Garantía y entrega','Confirma por escrito cuántos meses de garantía incluye, qué cubre y quién la gestiona. Revisa también qué documentación recibes el día de la entrega.']]},
 { slug:'como-vender-tu-coche-tasacion-paso-a-paso', title:'Cómo vender tu coche: tasación paso a paso',
   answer:'Para vender tu coche reúne la documentación, indica marca, modelo, año y kilómetros en el formulario de tasación, recibe una oferta personalizada y, si la aceptas, concierta cita para la revisión y la firma.',
   body:[['Prepara la documentación','Ten a mano el permiso de circulación, la ficha técnica, la ITV en vigor y el último recibo del impuesto de circulación.'],
         ['Pide la tasación','Cuantos más datos des (versión, equipamiento, kilómetros, estado), más ajustada será la oferta. Añade cualquier punto que el coche tenga: golpes, averías, mantenimiento reciente.'],
         ['Revisión y oferta final','Vemos el coche en persona y confirmamos la oferta. Si algo difiere de lo indicado, te lo explicamos antes de cerrar.'],
         ['Firma y cambio de titularidad','Firmamos el contrato y gestionamos el cambio de titular para que no te quede ningún trámite pendiente.']]},
 { slug:'financiar-un-coche-cuota-entrada-y-plazo', title:'Financiar un coche: cuota, entrada y plazo',
   answer:'La cuota depende de tres cosas: el importe que financias, el plazo y el tipo de interés. Una entrada mayor y un plazo más corto reducen el coste total, aunque suban la cuota mensual.',
   body:[['Entrada','Cuanto más entregas al inicio, menos financias y menos intereses pagas. Tu coche actual puede ser parte de esa entrada.'],
         ['Plazo','Plazos largos bajan la cuota pero aumentan el coste total. Elige la cuota que puedas pagar sin tensión, no la más baja posible.'],
         ['Qué mirar en la oferta','Compara siempre el TIN, la TAE, las comisiones y el importe total a devolver. La TAE es la cifra que permite comparar ofertas entre sí.'],
         ['Simula antes de decidir','Usa el simulador de la página de financiación para tener una idea orientativa. La oferta definitiva la da la entidad financiera.']]},
];
